package com.example.kpopconcerttracker

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

/*
 * Reschedules future concert reminders after the device restarts.
 *
 * Android removes AlarmManager alarms when a device reboots,
 * so future reminders must be scheduled again.
 */
class BootReceiver :
    BroadcastReceiver() {

    override fun onReceive(
        context: Context,
        intent: Intent
    ) {

        if (
            intent.action !=
            Intent.ACTION_BOOT_COMPLETED
        ) {

            return
        }

        /*
         * Do not attempt to schedule SMS reminders if the user
         * has denied SMS permission.
         */
        if (
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.SEND_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {

            return
        }

        val userId =
            SessionManager.getUserId(
                context
            )

        if (userId > 0) {

            ReminderScheduler.scheduleAllReminders(
                context,
                userId
            )
        }
    }
}