package com.example.kpopconcerttracker

/*
 * Data class representing one concert stored in SQLite.
 *
 * Keeping database records in a simple data class makes the
 * information easy for the RecyclerView adapter and Activities
 * to work with.
 */
data class ConcertEvent(
    val id: Long,
    val userId: Long,
    val title: String,
    val artist: String,
    val date: String,
    val time: String,
    val location: String,
    val category: String,
    val notes: String
)