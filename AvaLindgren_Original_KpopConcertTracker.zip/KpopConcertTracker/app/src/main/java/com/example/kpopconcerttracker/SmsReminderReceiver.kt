package com.example.kpopconcerttracker

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import androidx.core.content.ContextCompat

/**
 * BroadcastReceiver responsible for sending an SMS reminder
 * when a scheduled concert reminder is triggered.
 *
 * The receiver checks SMS permission before attempting to send
 * a message. If permission has been denied, the application
 * simply exits this notification process and continues working.
 */
class SmsReminderReceiver : BroadcastReceiver() {

    override fun onReceive(
        context: Context,
        intent: Intent
    ) {

        /*
         * Retrieve the information about the concert from
         * the Intent that scheduled this reminder.
         */
        val artist =
            intent.getStringExtra("artist") ?: "K-pop Artist"

        val concertName =
            intent.getStringExtra("concertName") ?: "Upcoming Concert"

        val concertDate =
            intent.getStringExtra("concertDate") ?: "today"

        /*
         * Retrieve the phone number that the user selected
         * for SMS reminders.
         */
        val phoneNumber =
            intent.getStringExtra("phoneNumber")

        /*
         * There is no destination number, so there is
         * nothing to send.
         */
        if (phoneNumber.isNullOrBlank()) {
            return
        }

        /*
         * Check SEND_SMS permission before attempting
         * to communicate with the SMS service.
         *
         * This is required because SEND_SMS is a
         * dangerous runtime permission.
         */
        if (
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.SEND_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            /*
             * The user denied SMS permission.
             *
             * The rest of the application continues
             * to function normally without SMS reminders.
             */
            return
        }

        /*
         * Obtain the default SMS subscription.
         *
         * This avoids the deprecated SmsManager.getDefault()
         * method and uses the current Android subscription API.
         */
        val subscriptionId =
            SubscriptionManager.getDefaultSmsSubscriptionId()

        /*
         * Create an SmsManager associated with the selected
         * subscription.
         */
        val smsManager =
            if (subscriptionId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {

                SmsManager.getSmsManagerForSubscriptionId(
                    subscriptionId
                )

            } else {

                /*
                 * If the emulator/device does not have a valid
                 * SMS subscription, there is no SMS service
                 * available for this reminder.
                 */
                return
            }

        /*
         * Build the reminder message using the concert
         * information stored in the database.
         */
        val message =
            "K-pop Concert Reminder: $concertName by $artist " +
                    "is scheduled for $concertDate."

        /*
         * Send the SMS reminder.
         *
         * No delivery PendingIntent is necessary for this
         * project because the rubric only requires that the
         * application send the alert when permission exists.
         */
        smsManager.sendTextMessage(
            phoneNumber,
            null,
            message,
            null,
            null
        )
    }
}