package com.example.kpopconcerttracker

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/*
 * Creates and edits individual concert records.
 */
class EventDetailsActivity :
    AppCompatActivity() {

    companion object {

        const val EXTRA_EVENT_ID =
            "event_id"
    }

    private lateinit var titleInput: EditText
    private lateinit var artistInput: EditText
    private lateinit var dateInput: EditText
    private lateinit var timeInput: EditText
    private lateinit var locationInput: EditText
    private lateinit var categorySpinner: Spinner
    private lateinit var notesInput: EditText

    private lateinit var databaseHelper: DatabaseHelper

    private var editingEventId =
        -1L

    private val userId: Long
        get() =
            SessionManager.getUserId(this)

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {
        super.onCreate(savedInstanceState)

        setContentView(
            R.layout.activity_event_details
        )

        if (userId <= 0) {

            finish()

            return
        }

        databaseHelper =
            DatabaseHelper(this)

        titleInput =
            findViewById(
                R.id.etEventTitle
            )

        artistInput =
            findViewById(
                R.id.etArtist
            )

        dateInput =
            findViewById(
                R.id.etEventDate
            )

        timeInput =
            findViewById(
                R.id.etEventTime
            )

        locationInput =
            findViewById(
                R.id.etLocation
            )

        categorySpinner =
            findViewById(
                R.id.spinnerEventCategory
            )

        notesInput =
            findViewById(
                R.id.etNotes
            )

        val saveButton =
            findViewById<Button>(
                R.id.btnSaveEvent
            )

        val cancelButton =
            findViewById<Button>(
                R.id.btnCancelEvent
            )

        setupCategorySpinner()

        /*
         * Date and time fields open standard Android pickers.
         */
        dateInput.setOnClickListener {

            showDatePicker()
        }

        timeInput.setOnClickListener {

            showTimePicker()
        }

        /*
         * Check whether this Activity is editing an existing record.
         */
        editingEventId =
            intent.getLongExtra(
                EXTRA_EVENT_ID,
                -1L
            )

        if (editingEventId > 0) {

            loadExistingEvent()
        }

        saveButton.setOnClickListener {

            saveEvent()
        }

        cancelButton.setOnClickListener {

            finish()
        }
    }

    private fun setupCategorySpinner() {

        val categories =
            listOf(
                "Boy Groups",
                "Girl Groups",
                "Solo Artists",
                "Co-ed Groups"
            )

        val adapter =
            ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                categories
            )

        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        categorySpinner.adapter =
            adapter
    }

    /*
     * Loads a record when the user selected Edit.
     */
    private fun loadExistingEvent() {

        val event =
            databaseHelper.getEvent(
                editingEventId,
                userId
            )
                ?: return

        titleInput.setText(
            event.title
        )

        artistInput.setText(
            event.artist
        )

        dateInput.setText(
            event.date
        )

        timeInput.setText(
            event.time
        )

        locationInput.setText(
            event.location
        )

        notesInput.setText(
            event.notes
        )

        val categories =
            resources.getStringArray(
                R.array.concert_categories
            )

        val selectedIndex =
            categories.indexOf(
                event.category
            )

        if (selectedIndex >= 0) {

            categorySpinner.setSelection(
                selectedIndex
            )
        }
    }

    /*
     * Saves either a new record or changes to an existing record.
     */
    private fun saveEvent() {

        val title =
            titleInput.text
                .toString()
                .trim()

        val artist =
            artistInput.text
                .toString()
                .trim()

        val date =
            dateInput.text
                .toString()
                .trim()

        val time =
            timeInput.text
                .toString()
                .trim()

        val location =
            locationInput.text
                .toString()
                .trim()

        val category =
            categorySpinner.selectedItem
                ?.toString()
                ?: ""

        val notes =
            notesInput.text
                .toString()
                .trim()

        if (title.isEmpty() ||
            artist.isEmpty() ||
            date.isEmpty() ||
            time.isEmpty() ||
            location.isEmpty()
        ) {

            Toast.makeText(
                this,
                "Please complete all required event fields.",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        if (!isValidDateTime(
                date,
                time
            )
        ) {

            Toast.makeText(
                this,
                "Enter a valid date and time.",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        if (editingEventId > 0) {

            /*
             * Cancel the previous reminder before replacing the
             * event's date/time.
             */
            ReminderScheduler.cancelReminder(
                this,
                editingEventId
            )

            databaseHelper.updateEvent(
                editingEventId,
                userId,
                title,
                artist,
                date,
                time,
                location,
                category,
                notes
            )

            /*
             * If SMS permission is currently granted, schedule
             * the updated reminder.
             */
            ReminderScheduler.scheduleEventReminder(
                this,
                editingEventId,
                userId
            )

            Toast.makeText(
                this,
                "Concert updated.",
                Toast.LENGTH_SHORT
            ).show()

        } else {

            val newEventId =
                databaseHelper.insertEvent(
                    userId,
                    title,
                    artist,
                    date,
                    time,
                    location,
                    category,
                    notes
                )

            if (newEventId > 0) {

                ReminderScheduler.scheduleEventReminder(
                    this,
                    newEventId,
                    userId
                )

                Toast.makeText(
                    this,
                    "Concert added.",
                    Toast.LENGTH_SHORT
                ).show()

            } else {

                Toast.makeText(
                    this,
                    "Unable to save the concert.",
                    Toast.LENGTH_SHORT
                ).show()

                return
            }
        }

        finish()
    }

    private fun showDatePicker() {

        val calendar =
            Calendar.getInstance()

        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->

                val selectedDate =
                    Calendar.getInstance()

                selectedDate.set(
                    year,
                    month,
                    dayOfMonth
                )

                val formatter =
                    SimpleDateFormat(
                        "yyyy-MM-dd",
                        Locale.US
                    )

                dateInput.setText(
                    formatter.format(
                        selectedDate.time
                    )
                )
            },
            calendar.get(
                Calendar.YEAR
            ),
            calendar.get(
                Calendar.MONTH
            ),
            calendar.get(
                Calendar.DAY_OF_MONTH
            )
        ).show()
    }

    private fun showTimePicker() {

        val calendar =
            Calendar.getInstance()

        TimePickerDialog(
            this,
            { _, hourOfDay, minute ->

                timeInput.setText(
                    String.format(
                        Locale.US,
                        "%02d:%02d",
                        hourOfDay,
                        minute
                    )
                )
            },
            calendar.get(
                Calendar.HOUR_OF_DAY
            ),
            calendar.get(
                Calendar.MINUTE
            ),
            true
        ).show()
    }

    /*
     * Validates the date/time format before storing the record.
     */
    private fun isValidDateTime(
        date: String,
        time: String
    ): Boolean {

        return try {

            val formatter =
                SimpleDateFormat(
                    "yyyy-MM-dd HH:mm",
                    Locale.US
                )

            formatter.isLenient = false

            formatter.parse(
                "$date $time"
            )

            true

        } catch (
            exception: Exception
        ) {

            false
        }
    }
}