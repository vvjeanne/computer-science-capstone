package com.example.kpopconcerttracker

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/*
 * Handles both existing-user login and new account creation.
 *
 * The same screen is intentionally used for both operations
 * to keep the user experience simple.
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var usernameInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var phoneInput: EditText

    private lateinit var loginButton: Button
    private lateinit var createAccountButton: Button

    private lateinit var statusText: TextView

    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {
        super.onCreate(savedInstanceState)

        setContentView(
            R.layout.activity_login
        )

        databaseHelper =
            DatabaseHelper(this)

        usernameInput =
            findViewById(
                R.id.etUsername
            )

        passwordInput =
            findViewById(
                R.id.etPassword
            )

        phoneInput =
            findViewById(
                R.id.etPhone
            )

        loginButton =
            findViewById(
                R.id.btnLogin
            )

        createAccountButton =
            findViewById(
                R.id.btnCreateAccount
            )

        statusText =
            findViewById(
                R.id.tvLoginStatus
            )

        /*
         * Explicitly configure the password field so entered
         * characters are obscured.
         */
        passwordInput.inputType =
            InputType.TYPE_CLASS_TEXT or
                    InputType.TYPE_TEXT_VARIATION_PASSWORD

        loginButton.setOnClickListener {

            loginUser()
        }

        createAccountButton.setOnClickListener {

            createAccount()
        }
    }

    /*
     * Validates login information and checks the SQLite database.
     */
    private fun loginUser() {

        val username =
            usernameInput.text
                .toString()
                .trim()

        val password =
            passwordInput.text
                .toString()

        if (username.isEmpty() ||
            password.isEmpty()
        ) {

            showStatus(
                "Please enter your username and password."
            )

            return
        }

        val userId =
            databaseHelper.authenticateUser(
                username,
                password
            )

        if (userId > 0) {

            /*
             * Store the authenticated user ID so the dashboard
             * only displays that user's concert records.
             */
            SessionManager.saveUserId(
                this,
                userId
            )

            startActivity(
                Intent(
                    this,
                    ConcertDashboardActivity::class.java
                )
            )

            finish()

        } else {

            showStatus(
                "Username or password is incorrect."
            )
        }
    }

    /*
     * Creates a new account and stores it in SQLite.
     *
     * The phone number is required for new accounts because
     * it provides the destination for concert reminder SMS messages.
     */
    private fun createAccount() {

        val username =
            usernameInput.text
                .toString()
                .trim()

        val password =
            passwordInput.text
                .toString()

        val phone =
            phoneInput.text
                .toString()
                .trim()

        if (username.length < 3) {

            showStatus(
                "Username must contain at least 3 characters."
            )

            return
        }

        if (password.length < 6) {

            showStatus(
                "Password must contain at least 6 characters."
            )

            return
        }

        if (phone.length < 7) {

            showStatus(
                "Enter a valid mobile phone number for SMS reminders."
            )

            return
        }

        val newUserId =
            databaseHelper.createUser(
                username,
                password,
                phone
            )

        if (newUserId > 0) {

            SessionManager.saveUserId(
                this,
                newUserId
            )

            Toast.makeText(
                this,
                "Account created successfully.",
                Toast.LENGTH_SHORT
            ).show()

            startActivity(
                Intent(
                    this,
                    ConcertDashboardActivity::class.java
                )
            )

            finish()

        } else {

            showStatus(
                "That username already exists. Please choose another."
            )
        }
    }

    private fun showStatus(
        message: String
    ) {

        statusText.text = message
    }
}