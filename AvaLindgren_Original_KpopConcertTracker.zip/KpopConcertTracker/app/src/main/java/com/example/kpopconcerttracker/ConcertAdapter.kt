package com.example.kpopconcerttracker

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/*
 * RecyclerView adapter responsible only for displaying concert
 * records and forwarding Edit/Delete actions to the dashboard.
 */
class ConcertAdapter(
    private var events: MutableList<ConcertEvent>,
    private val listener: ConcertActionListener
) : RecyclerView.Adapter<ConcertAdapter.ConcertViewHolder>() {

    interface ConcertActionListener {

        fun onEditEvent(
            event: ConcertEvent
        )

        fun onDeleteEvent(
            event: ConcertEvent
        )
    }

    class ConcertViewHolder(
        itemView: View
    ) : RecyclerView.ViewHolder(itemView) {

        val title: TextView =
            itemView.findViewById(
                R.id.tvEventTitle
            )

        val artist: TextView =
            itemView.findViewById(
                R.id.tvEventArtist
            )

        val date: TextView =
            itemView.findViewById(
                R.id.tvEventDate
            )

        val time: TextView =
            itemView.findViewById(
                R.id.tvEventTime
            )

        val location: TextView =
            itemView.findViewById(
                R.id.tvEventLocation
            )

        val category: TextView =
            itemView.findViewById(
                R.id.tvEventCategory
            )

        val notes: TextView =
            itemView.findViewById(
                R.id.tvEventNotes
            )

        val editButton: Button =
            itemView.findViewById(
                R.id.btnEditEvent
            )

        val deleteButton: Button =
            itemView.findViewById(
                R.id.btnDeleteEvent
            )
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ConcertViewHolder {

        val view =
            LayoutInflater.from(
                parent.context
            ).inflate(
                R.layout.item_concert,
                parent,
                false
            )

        return ConcertViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: ConcertViewHolder,
        position: Int
    ) {

        val event =
            events[position]

        holder.title.text =
            event.title

        holder.artist.text =
            "Artist: ${event.artist}"

        holder.date.text =
            "Date: ${event.date}"

        holder.time.text =
            "Time: ${event.time}"

        holder.location.text =
            "Location: ${event.location}"

        holder.category.text =
            "Category: ${event.category}"

        holder.notes.text =
            if (event.notes.isBlank()) {
                "Notes: None"
            } else {
                "Notes: ${event.notes}"
            }

        holder.editButton.setOnClickListener {

            listener.onEditEvent(event)
        }

        holder.deleteButton.setOnClickListener {

            listener.onDeleteEvent(event)
        }
    }

    override fun getItemCount(): Int =
        events.size

    /*
     * Replaces the displayed records after a database refresh
     * or category filter change.
     */
    fun updateEvents(
        newEvents: MutableList<ConcertEvent>
    ) {

        events =
            newEvents

        notifyDataSetChanged()
    }
}