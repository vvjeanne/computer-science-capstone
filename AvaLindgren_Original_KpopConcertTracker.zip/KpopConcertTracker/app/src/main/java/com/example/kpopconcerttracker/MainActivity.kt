package com.example.kpopconcerttracker

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/*
 * MainActivity serves as the launcher Activity.
 *
 * The actual application starts with LoginActivity.
 * Keeping MainActivity as a small routing Activity keeps
 * the application's responsibilities separated.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Open the login screen when the application starts.
        startActivity(
            Intent(this, LoginActivity::class.java)
        )

        // MainActivity is no longer needed after launching LoginActivity.
        finish()
    }
}