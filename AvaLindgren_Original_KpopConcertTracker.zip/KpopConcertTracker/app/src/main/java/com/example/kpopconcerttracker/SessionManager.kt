package com.example.kpopconcerttracker

import android.content.Context

/*
 * Stores the currently logged-in user's ID.
 *
 * SharedPreferences is appropriate here because the application
 * only needs a small amount of session information.
 */
object SessionManager {

    private const val PREFS_NAME =
        "kpop_concert_tracker_session"

    private const val KEY_USER_ID =
        "user_id"

    fun saveUserId(
        context: Context,
        userId: Long
    ) {

        context.getSharedPreferences(
            PREFS_NAME,
            Context.MODE_PRIVATE
        )
            .edit()
            .putLong(KEY_USER_ID, userId)
            .apply()
    }

    fun getUserId(
        context: Context
    ): Long {

        return context.getSharedPreferences(
            PREFS_NAME,
            Context.MODE_PRIVATE
        )
            .getLong(
                KEY_USER_ID,
                -1L
            )
    }

    fun clear(
        context: Context
    ) {

        context.getSharedPreferences(
            PREFS_NAME,
            Context.MODE_PRIVATE
        )
            .edit()
            .clear()
            .apply()
    }
}