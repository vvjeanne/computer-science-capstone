package com.example.kpopconcerttracker

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/*
 * Main application screen.
 *
 * Responsibilities:
 *
 * - Read concert records from SQLite.
 * - Display records in a RecyclerView grid.
 * - Filter records by artist category.
 * - Open the add/edit screen.
 * - Delete records.
 * - Open SMS settings.
 * - Log the user out.
 */
class ConcertDashboardActivity :
    AppCompatActivity(),
    ConcertAdapter.ConcertActionListener {

    private lateinit var recyclerView: RecyclerView
    private lateinit var categorySpinner: Spinner
    private lateinit var emptyText: TextView

    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var adapter: ConcertAdapter

    private var allEvents =
        mutableListOf<ConcertEvent>()

    private val userId: Long
        get() =
            SessionManager.getUserId(this)

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {
        super.onCreate(savedInstanceState)

        /*
         * If the user somehow reaches this screen without
         * logging in, return them to LoginActivity.
         */
        if (userId <= 0) {

            returnToLogin()

            return
        }

        setContentView(
            R.layout.activity_concert_dashboard
        )

        databaseHelper =
            DatabaseHelper(this)

        recyclerView =
            findViewById(
                R.id.recyclerConcerts
            )

        categorySpinner =
            findViewById(
                R.id.spinnerCategory
            )

        emptyText =
            findViewById(
                R.id.tvEmptyEvents
            )

        val addButton =
            findViewById<Button>(
                R.id.btnAddEvent
            )

        val smsButton =
            findViewById<Button>(
                R.id.btnSmsSettings
            )

        val logoutButton =
            findViewById<Button>(
                R.id.btnLogout
            )

        /*
         * Two columns provide a visual grid while allowing
         * each concert card to contain its complete information.
         */
        recyclerView.layoutManager =
            GridLayoutManager(
                this,
                2
            )

        adapter =
            ConcertAdapter(
                mutableListOf(),
                this
            )

        recyclerView.adapter =
            adapter

        setupCategorySpinner()

        addButton.setOnClickListener {

            startActivity(
                Intent(
                    this,
                    EventDetailsActivity::class.java
                )
            )
        }

        smsButton.setOnClickListener {

            startActivity(
                Intent(
                    this,
                    SmsPermissionActivity::class.java
                )
            )
        }

        logoutButton.setOnClickListener {

            logout()
        }
    }

    override fun onResume() {
        super.onResume()

        if (userId > 0) {

            loadEvents()
        }
    }

    /*
     * Loads concert records from SQLite.
     */
    private fun loadEvents() {

        allEvents =
            databaseHelper.getEventsForUser(
                userId
            )

        applyCategoryFilter()
    }

    /*
     * Creates the category filter.
     */
    private fun setupCategorySpinner() {

        val categories =
            listOf(
                "All Categories",
                "Boy Groups",
                "Girl Groups",
                "Solo Artists",
                "Co-ed Groups"
            )

        val spinnerAdapter =
            ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                categories
            )

        spinnerAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        categorySpinner.adapter =
            spinnerAdapter

        categorySpinner.onItemSelectedListener =
            object :
                android.widget.AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?,
                    view: android.view.View?,
                    position: Int,
                    id: Long
                ) {

                    applyCategoryFilter()
                }

                override fun onNothingSelected(
                    parent: android.widget.AdapterView<*>?
                ) {
                    // No action is necessary.
                }
            }
    }

    /*
     * Applies the selected category filter.
     */
    private fun applyCategoryFilter() {

        val selectedCategory =
            categorySpinner.selectedItem
                ?.toString()
                ?: "All Categories"

        val filteredEvents =
            if (selectedCategory == "All Categories") {

                allEvents

            } else {

                allEvents.filter {
                    it.category == selectedCategory
                }.toMutableList()
            }

        adapter.updateEvents(
            filteredEvents
        )

        emptyText.visibility =
            if (filteredEvents.isEmpty()) {
                TextView.VISIBLE
            } else {
                TextView.GONE
            }
    }

    /*
     * Opens the event editor for an existing concert.
     */
    override fun onEditEvent(
        event: ConcertEvent
    ) {

        val intent =
            Intent(
                this,
                EventDetailsActivity::class.java
            )

        intent.putExtra(
            EventDetailsActivity.EXTRA_EVENT_ID,
            event.id
        )

        startActivity(intent)
    }

    /*
     * Deletes a concert after asking for confirmation.
     */
    override fun onDeleteEvent(
        event: ConcertEvent
    ) {

        AlertDialog.Builder(this)
            .setTitle("Delete Concert")
            .setMessage(
                "Are you sure you want to delete ${event.title}?"
            )
            .setPositiveButton("Delete") { _, _ ->

                databaseHelper.deleteEvent(
                    event.id,
                    userId
                )

                ReminderScheduler.cancelReminder(
                    this,
                    event.id
                )

                loadEvents()

                Toast.makeText(
                    this,
                    "Concert deleted.",
                    Toast.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton(
                "Cancel",
                null
            )
            .show()
    }

    /*
     * Clears the login session and returns to LoginActivity.
     */
    private fun logout() {

        SessionManager.clear(this)

        returnToLogin()
    }

    private fun returnToLogin() {

        startActivity(
            Intent(
                this,
                LoginActivity::class.java
            )
        )

        finish()
    }
}