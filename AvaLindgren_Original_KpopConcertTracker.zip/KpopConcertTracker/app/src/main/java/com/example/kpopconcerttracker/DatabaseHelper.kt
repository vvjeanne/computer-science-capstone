package com.example.kpopconcerttracker

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest

/*
 * SQLite database manager for the K-Pop Concert Tracker.
 *
 * The database contains:
 *
 * 1. users
 *    Stores account information.
 *
 * 2. events
 *    Stores concert information associated with a user.
 *
 * SQLiteOpenHelper handles creating and opening the persistent
 * database used by the application.
 */
class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(
        context,
        DATABASE_NAME,
        null,
        DATABASE_VERSION
    ) {

    companion object {

        /*
         * A separate database name is used for Project Three so
         * the new schema does not conflict with the earlier
         * Project Two test database.
         */
        private const val DATABASE_NAME =
            "kpop_concert_tracker_project3.db"

        private const val DATABASE_VERSION = 1

        // User table.
        private const val TABLE_USERS = "users"

        private const val USER_ID = "id"
        private const val USERNAME = "username"
        private const val PASSWORD = "password"
        private const val PHONE = "phone"

        // Concert event table.
        private const val TABLE_EVENTS = "events"

        private const val EVENT_ID = "id"
        private const val EVENT_USER_ID = "user_id"
        private const val EVENT_TITLE = "title"
        private const val EVENT_ARTIST = "artist"
        private const val EVENT_DATE = "event_date"
        private const val EVENT_TIME = "event_time"
        private const val EVENT_LOCATION = "location"
        private const val EVENT_CATEGORY = "category"
        private const val EVENT_NOTES = "notes"
    }

    override fun onCreate(db: SQLiteDatabase) {

        /*
         * User table.
         *
         * The username is unique so duplicate accounts cannot
         * be created.
         */
        db.execSQL(
            """
            CREATE TABLE $TABLE_USERS (
                $USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $USERNAME TEXT NOT NULL UNIQUE,
                $PASSWORD TEXT NOT NULL,
                $PHONE TEXT NOT NULL
            )
            """.trimIndent()
        )

        /*
         * Concert table.
         *
         * user_id associates each concert with the account that
         * created it.
         */
        db.execSQL(
            """
            CREATE TABLE $TABLE_EVENTS (
                $EVENT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $EVENT_USER_ID INTEGER NOT NULL,
                $EVENT_TITLE TEXT NOT NULL,
                $EVENT_ARTIST TEXT NOT NULL,
                $EVENT_DATE TEXT NOT NULL,
                $EVENT_TIME TEXT NOT NULL,
                $EVENT_LOCATION TEXT NOT NULL,
                $EVENT_CATEGORY TEXT NOT NULL,
                $EVENT_NOTES TEXT,
                FOREIGN KEY ($EVENT_USER_ID)
                    REFERENCES $TABLE_USERS($USER_ID)
                    ON DELETE CASCADE
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        /*
         * This project uses a new database name, so this method
         * is primarily here for standard SQLite version management.
         *
         * Future database schema changes should be added here
         * rather than silently changing an existing migration.
         */
    }

    /*
     * Creates a new user account.
     *
     * Returns:
     *   > 0 = database row ID
     *   -1 = username already exists or insertion failed
     */
    fun createUser(
        username: String,
        password: String,
        phone: String
    ): Long {

        val db = writableDatabase

        val values = ContentValues().apply {
            put(USERNAME, username)
            put(PASSWORD, hashPassword(password))
            put(PHONE, phone)
        }

        return try {

            db.insertOrThrow(
                TABLE_USERS,
                null,
                values
            )

        } catch (exception: Exception) {

            -1L
        }
    }

    /*
     * Checks the supplied username and password against
     * the users table.
     *
     * Passwords are hashed before comparison so the database
     * does not store the original password as plain text.
     */
    fun authenticateUser(
        username: String,
        password: String
    ): Long {

        val db = readableDatabase

        val hashedPassword =
            hashPassword(password)

        val cursor = db.query(
            TABLE_USERS,
            arrayOf(USER_ID),
            "$USERNAME = ? AND $PASSWORD = ?",
            arrayOf(username, hashedPassword),
            null,
            null,
            null
        )

        cursor.use {

            return if (it.moveToFirst()) {
                it.getLong(
                    it.getColumnIndexOrThrow(USER_ID)
                )
            } else {
                -1L
            }
        }
    }

    /*
     * Returns the mobile number associated with an account.
     */
    fun getUserPhone(userId: Long): String? {

        val db = readableDatabase

        val cursor = db.query(
            TABLE_USERS,
            arrayOf(PHONE),
            "$USER_ID = ?",
            arrayOf(userId.toString()),
            null,
            null,
            null
        )

        cursor.use {

            return if (it.moveToFirst()) {
                it.getString(
                    it.getColumnIndexOrThrow(PHONE)
                )
            } else {
                null
            }
        }
    }

    /*
     * Creates a new concert event.
     */
    fun insertEvent(
        userId: Long,
        title: String,
        artist: String,
        date: String,
        time: String,
        location: String,
        category: String,
        notes: String
    ): Long {

        val db = writableDatabase

        val values = ContentValues().apply {

            put(EVENT_USER_ID, userId)
            put(EVENT_TITLE, title)
            put(EVENT_ARTIST, artist)
            put(EVENT_DATE, date)
            put(EVENT_TIME, time)
            put(EVENT_LOCATION, location)
            put(EVENT_CATEGORY, category)
            put(EVENT_NOTES, notes)
        }

        return db.insert(
            TABLE_EVENTS,
            null,
            values
        )
    }

    /*
     * Reads all concert events for the current user.
     */
    fun getEventsForUser(
        userId: Long
    ): MutableList<ConcertEvent> {

        val events = mutableListOf<ConcertEvent>()

        val db = readableDatabase

        val cursor = db.query(
            TABLE_EVENTS,
            null,
            "$EVENT_USER_ID = ?",
            arrayOf(userId.toString()),
            null,
            null,
            "$EVENT_DATE ASC, $EVENT_TIME ASC"
        )

        cursor.use {

            while (it.moveToNext()) {

                events.add(
                    ConcertEvent(
                        id = it.getLong(
                            it.getColumnIndexOrThrow(EVENT_ID)
                        ),
                        userId = it.getLong(
                            it.getColumnIndexOrThrow(EVENT_USER_ID)
                        ),
                        title = it.getString(
                            it.getColumnIndexOrThrow(EVENT_TITLE)
                        ),
                        artist = it.getString(
                            it.getColumnIndexOrThrow(EVENT_ARTIST)
                        ),
                        date = it.getString(
                            it.getColumnIndexOrThrow(EVENT_DATE)
                        ),
                        time = it.getString(
                            it.getColumnIndexOrThrow(EVENT_TIME)
                        ),
                        location = it.getString(
                            it.getColumnIndexOrThrow(EVENT_LOCATION)
                        ),
                        category = it.getString(
                            it.getColumnIndexOrThrow(EVENT_CATEGORY)
                        ),
                        notes = it.getString(
                            it.getColumnIndexOrThrow(EVENT_NOTES)
                        )
                    )
                )
            }
        }

        return events
    }

    /*
     * Returns one event by ID.
     */
    fun getEvent(
        eventId: Long,
        userId: Long
    ): ConcertEvent? {

        val db = readableDatabase

        val cursor = db.query(
            TABLE_EVENTS,
            null,
            "$EVENT_ID = ? AND $EVENT_USER_ID = ?",
            arrayOf(
                eventId.toString(),
                userId.toString()
            ),
            null,
            null,
            null
        )

        cursor.use {

            if (!it.moveToFirst()) {
                return null
            }

            return ConcertEvent(
                id = it.getLong(
                    it.getColumnIndexOrThrow(EVENT_ID)
                ),
                userId = it.getLong(
                    it.getColumnIndexOrThrow(EVENT_USER_ID)
                ),
                title = it.getString(
                    it.getColumnIndexOrThrow(EVENT_TITLE)
                ),
                artist = it.getString(
                    it.getColumnIndexOrThrow(EVENT_ARTIST)
                ),
                date = it.getString(
                    it.getColumnIndexOrThrow(EVENT_DATE)
                ),
                time = it.getString(
                    it.getColumnIndexOrThrow(EVENT_TIME)
                ),
                location = it.getString(
                    it.getColumnIndexOrThrow(EVENT_LOCATION)
                ),
                category = it.getString(
                    it.getColumnIndexOrThrow(EVENT_CATEGORY)
                ),
                notes = it.getString(
                    it.getColumnIndexOrThrow(EVENT_NOTES)
                )
            )
        }
    }

    /*
     * Updates an existing concert event.
     */
    fun updateEvent(
        eventId: Long,
        userId: Long,
        title: String,
        artist: String,
        date: String,
        time: String,
        location: String,
        category: String,
        notes: String
    ): Int {

        val db = writableDatabase

        val values = ContentValues().apply {

            put(EVENT_TITLE, title)
            put(EVENT_ARTIST, artist)
            put(EVENT_DATE, date)
            put(EVENT_TIME, time)
            put(EVENT_LOCATION, location)
            put(EVENT_CATEGORY, category)
            put(EVENT_NOTES, notes)
        }

        return db.update(
            TABLE_EVENTS,
            values,
            "$EVENT_ID = ? AND $EVENT_USER_ID = ?",
            arrayOf(
                eventId.toString(),
                userId.toString()
            )
        )
    }

    /*
     * Deletes a concert event.
     */
    fun deleteEvent(
        eventId: Long,
        userId: Long
    ): Int {

        val db = writableDatabase

        return db.delete(
            TABLE_EVENTS,
            "$EVENT_ID = ? AND $EVENT_USER_ID = ?",
            arrayOf(
                eventId.toString(),
                userId.toString()
            )
        )
    }

    /*
     * Hashes a password with SHA-256 before it is stored or compared.
     */
    private fun hashPassword(
        password: String
    ): String {

        val digest =
            MessageDigest.getInstance("SHA-256")

        val hash =
            digest.digest(
                password.toByteArray(
                    Charsets.UTF_8
                )
            )

        return hash.joinToString("") {
            "%02x".format(it)
        }
    }
}