package com.example.kpopconcerttracker

/*
 * Concert represents one concert/event record.
 *
 * Project Two:
 * These properties are used to demonstrate sample information
 * in the UI.
 *
 * Project Three:
 * This model can be connected to the concert database.
 */
data class Concert(

    val id: Int,

    val concertName: String,

    val artist: String,

    val date: String,

    val time: String,

    val location: String,

    val category: String,

    val notes: String = ""

)