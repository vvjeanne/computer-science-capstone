package com.example.kpopconcerttracker

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/*
 * Responsible for scheduling and cancelling concert reminder alarms.
 *
 * A reminder is scheduled for one hour before the saved concert
 * start time.
 */
object ReminderScheduler {

    private const val EXTRA_EVENT_ID =
        "event_id"

    private const val EXTRA_USER_ID =
        "user_id"

    private const val REMINDER_OFFSET_MILLIS =
        60L * 60L * 1000L

    /*
     * Schedules a reminder for one concert.
     */
    fun scheduleEventReminder(
        context: Context,
        eventId: Long,
        userId: Long
    ) {

        /*
         * Never schedule an SMS reminder unless the user has
         * granted SEND_SMS.
         */
        if (
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.SEND_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {

            return
        }

        val databaseHelper =
            DatabaseHelper(context)

        val event =
            databaseHelper.getEvent(
                eventId,
                userId
            )
                ?: return

        val eventTime =
            parseEventTime(
                event.date,
                event.time
            )
                ?: return

        /*
         * Send the reminder one hour before the concert.
         */
        var triggerTime =
            eventTime - REMINDER_OFFSET_MILLIS

        val currentTime =
            System.currentTimeMillis()

        /*
         * This makes same-day testing easier. If the event is
         * less than one hour away, the reminder is scheduled
         * approximately five seconds from now.
         *
         * If the event has already passed, no reminder is scheduled.
         */
        if (triggerTime <= currentTime) {

            if (eventTime > currentTime) {

                triggerTime =
                    currentTime + 5_000L

            } else {

                return
            }
        }

        val alarmManager =
            context.getSystemService(
                Context.ALARM_SERVICE
            ) as AlarmManager

        val pendingIntent =
            createPendingIntent(
                context,
                eventId,
                userId
            )

        /*
         * setAndAllowWhileIdle is used instead of an exact alarm
         * so the application does not require the additional
         * SCHEDULE_EXACT_ALARM special permission.
         */
        alarmManager.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            triggerTime,
            pendingIntent
        )
    }

    /*
     * Schedules all future events for a user.
     */
    fun scheduleAllReminders(
        context: Context,
        userId: Long
    ) {

        val databaseHelper =
            DatabaseHelper(context)

        val events =
            databaseHelper.getEventsForUser(
                userId
            )

        for (event in events) {

            scheduleEventReminder(
                context,
                event.id,
                userId
            )
        }
    }

    /*
     * Cancels a scheduled reminder.
     */
    fun cancelReminder(
        context: Context,
        eventId: Long
    ) {

        val alarmManager =
            context.getSystemService(
                Context.ALARM_SERVICE
            ) as AlarmManager

        val intent =
            Intent(
                context,
                SmsReminderReceiver::class.java
            )

        intent.putExtra(
            EXTRA_EVENT_ID,
            eventId
        )

        val pendingIntent =
            PendingIntent.getBroadcast(
                context,
                eventId.toInt(),
                intent,
                PendingIntent.FLAG_IMMUTABLE or
                        PendingIntent.FLAG_NO_CREATE
            )

        if (pendingIntent != null) {

            alarmManager.cancel(
                pendingIntent
            )

            pendingIntent.cancel()
        }
    }

    /*
     * Creates the PendingIntent used by AlarmManager.
     *
     * The intent explicitly identifies the receiver and uses
     * FLAG_IMMUTABLE for security.
     */
    private fun createPendingIntent(
        context: Context,
        eventId: Long,
        userId: Long
    ): PendingIntent {

        val intent =
            Intent(
                context,
                SmsReminderReceiver::class.java
            )

        intent.putExtra(
            EXTRA_EVENT_ID,
            eventId
        )

        intent.putExtra(
            EXTRA_USER_ID,
            userId
        )

        return PendingIntent.getBroadcast(
            context,
            eventId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                    PendingIntent.FLAG_IMMUTABLE
        )
    }

    /*
     * Converts the database date/time format into a millisecond
     * timestamp used by AlarmManager.
     */
    private fun parseEventTime(
        date: String,
        time: String
    ): Long? {

        return try {

            val formatter =
                SimpleDateFormat(
                    "yyyy-MM-dd HH:mm",
                    Locale.US
                )

            formatter.isLenient =
                false

            formatter.parse(
                "$date $time"
            )?.time

        } catch (
            exception: Exception
        ) {

            null
        }
    }
}