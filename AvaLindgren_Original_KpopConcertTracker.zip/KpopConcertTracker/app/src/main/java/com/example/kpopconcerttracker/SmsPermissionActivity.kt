package com.example.kpopconcerttracker

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/*
 * Handles the user's decision about SMS reminders.
 *
 * The application continues to work normally if the user
 * denies SMS permission.
 */
class SmsPermissionActivity :
    AppCompatActivity() {

    private lateinit var permissionStatus: TextView

    private val userId: Long
        get() =
            SessionManager.getUserId(this)

    /*
     * Android's Activity Result API receives the result of the
     * runtime SEND_SMS permission request.
     */
    private val smsPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted ->

            if (isGranted) {

                permissionStatus.text =
                    "SMS permission granted. Concert reminders are enabled."

                /*
                 * Schedule all future events after the user grants
                 * permission.
                 */
                if (userId > 0) {

                    ReminderScheduler.scheduleAllReminders(
                        this,
                        userId
                    )
                }

            } else {

                permissionStatus.text =
                    "SMS permission denied. The application will continue without SMS reminders."
            }
        }

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {
        super.onCreate(savedInstanceState)

        setContentView(
            R.layout.activity_sms_permission
        )

        permissionStatus =
            findViewById(
                R.id.tvPermissionStatus
            )

        val requestButton =
            findViewById<Button>(
                R.id.btnRequestSmsPermission
            )

        val continueButton =
            findViewById<Button>(
                R.id.btnContinueWithoutSms
            )

        updatePermissionStatus()

        requestButton.setOnClickListener {

            requestSmsPermission()
        }

        continueButton.setOnClickListener {

            finish()
        }
    }

    /*
     * Updates the screen according to the current permission state.
     */
    private fun updatePermissionStatus() {

        val permissionGranted =
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
            ) == PackageManager.PERMISSION_GRANTED

        permissionStatus.text =
            if (permissionGranted) {

                "SMS permission status: Granted"

            } else {

                "SMS permission status: Not granted"
            }
    }

    /*
     * Checks for SMS capability before asking Android to request
     * the dangerous SEND_SMS permission.
     */
    private fun requestSmsPermission() {

        /*
         * An emulator/device without SMS capability cannot send
         * a real text message. The rest of the application still
         * works normally.
         */
        if (!packageManager.hasSystemFeature(
                PackageManager.FEATURE_TELEPHONY_MESSAGING
            )
        ) {

            permissionStatus.text =
                "This device does not support SMS messaging."

            return
        }

        val permission =
            Manifest.permission.SEND_SMS

        if (
            ContextCompat.checkSelfPermission(
                this,
                permission
            ) == PackageManager.PERMISSION_GRANTED
        ) {

            permissionStatus.text =
                "SMS permission is already granted."

            if (userId > 0) {

                ReminderScheduler.scheduleAllReminders(
                    this,
                    userId
                )
            }

            return
        }

        /*
         * If Android indicates that the user previously denied
         * the permission and a rationale is appropriate, explain
         * why the permission is needed before requesting it again.
         */
        if (
            shouldShowRequestPermissionRationale(
                permission
            )
        ) {

            AlertDialog.Builder(this)
                .setTitle("SMS Reminder Permission")
                .setMessage(
                    "K-Pop Concert Tracker uses SMS permission to send you reminders before your saved concerts. The rest of the application will continue to work if you deny this permission."
                )
                .setPositiveButton("Continue") { _, _ ->

                    smsPermissionLauncher.launch(
                        permission
                    )
                }
                .setNegativeButton(
                    "Not Now",
                    null
                )
                .show()

        } else {

            smsPermissionLauncher.launch(
                permission
            )
        }
    }
}